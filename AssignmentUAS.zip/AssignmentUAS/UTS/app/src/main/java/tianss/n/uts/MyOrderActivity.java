package tianss.n.uts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MyOrderActivity extends AppCompatActivity implements View.OnClickListener{
    RecyclerView recyclerView;
    public static Integer AM=0,jApel=0,jMangga=0,jAlpukat=0;
    public static ArrayList<String> listDrinks=new ArrayList<>();
    public static ArrayList<String> listQty=new ArrayList<>();
    String qty[]={AM.toString(),jApel.toString(),jMangga.toString(),jAlpukat.toString()};
    String drinks[]={"Air Mineral","Jus Apel","Jus Mangga","Jus Alpukat"};
    public static Integer totall=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);
        TextView total=findViewById(R.id.txtTotal);
        Button btnPayNow = findViewById(R.id.btnPayNow);
        btnPayNow.setOnClickListener(this);
        totall=(AM+jAlpukat+jMangga+jApel)*123;
        String x="Total: Rp."+totall.toString();
        total.setText(x);
        if(AM!=0){
            listDrinks.add("Air Mineral");
            listQty.add(AM.toString());
        }
        if(jApel!=0){
            listDrinks.add("Jus Apel");
            listQty.add(jApel.toString());
        }
        if(jMangga!=0){
            listDrinks.add("Jus Mangga");
            listQty.add(jMangga.toString());
        }
        if(jAlpukat!=0){
            listDrinks.add("Jus Alpukat");
            listQty.add(jAlpukat.toString());
        }
        if(!listQty.isEmpty()){
            recyclerView=findViewById(R.id.rView);
            MyAdapter myAdapter= new MyAdapter(this,listDrinks,listQty);
            recyclerView.setAdapter(myAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }
    }

    @Override
    public void onClick(View view) {
        Intent moveIntent;
        switch (view.getId()) {
            case R.id.btnPayNow:
                moveIntent = new Intent(MyOrderActivity.this, OrderCompleteActivity.class);
                startActivity(moveIntent);
                break;
        }
    }
}
