package tianss.n.uts;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.MyViewHolder> {
    ArrayList<String> listDrinks=new ArrayList<>();
    ArrayList<String> listQty=new ArrayList<>();
    Context context;
    String datadrinks[];
    String dataqty[];
    public MyAdapter2(Context ct,ArrayList<String> listDrinkss,ArrayList<String> listQtyy){
        context =ct;
        listDrinks=listDrinkss;
        listQty=listQtyy;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.my_row2,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.myText1.setText(listDrinks.get(position));
        holder.myText2.setText(listQty.get(position)+"x Rp.123");
    }


    @Override
    public int getItemCount() {
        return listDrinks.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView myText1,myText2;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myText1=itemView.findViewById(R.id.txtOrder);
            myText2=itemView.findViewById(R.id.txtQty);
        }
    }
}
