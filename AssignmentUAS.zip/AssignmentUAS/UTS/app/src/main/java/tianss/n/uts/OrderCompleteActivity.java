package tianss.n.uts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OrderCompleteActivity extends AppCompatActivity  implements View.OnClickListener{
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_complete);
        recyclerView=findViewById(R.id.rView);
        TextView total=findViewById(R.id.txtTotal);
        MyOrderActivity.totall=(MyOrderActivity.AM+MyOrderActivity.jAlpukat+MyOrderActivity.jMangga+MyOrderActivity.jApel)*123;
        String x="Total: Rp."+MyOrderActivity.totall.toString();
        total.setText(x);
        MyAdapter2 myAdapter= new MyAdapter2(this, MyOrderActivity.listDrinks,MyOrderActivity.listQty);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button btnMenuUtama=findViewById(R.id.btnMenuUtama);
        btnMenuUtama.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent moveIntent;
        switch (view.getId()){
            case R.id.btnMenuUtama:
                moveIntent = new Intent(OrderCompleteActivity.this, MainActivity.class);
                MyOrderActivity.AM=0;
                MyOrderActivity.jAlpukat=0;
                MyOrderActivity.jMangga=0;
                MyOrderActivity.jApel=0;
                MyOrderActivity.listQty.clear();
                MyOrderActivity.listDrinks.clear();
                MyOrderActivity.totall=0;
                startActivity(moveIntent);
                break;
    }
    }
}
