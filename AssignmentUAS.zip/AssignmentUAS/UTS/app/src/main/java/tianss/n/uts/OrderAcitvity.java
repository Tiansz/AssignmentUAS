package tianss.n.uts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class OrderAcitvity extends AppCompatActivity implements View.OnClickListener {
    public static int order=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_acitvity);
        TextView txtOrder=findViewById(R.id.txtOrder);
        ImageView imgOrder=findViewById(R.id.imgOrder);
        Button btnMyOrder = findViewById(R.id.btnMyOrder);
        Button btnOrderMore= findViewById(R.id.btnOrderMore);
        btnOrderMore.setOnClickListener(this);
        btnMyOrder.setOnClickListener(this);
        String txtOrderr;
        switch (order){
            case 1:
                txtOrderr="Air Mineral\nRp 123";
                txtOrder.setText(txtOrderr);
                imgOrder.setImageResource(R.drawable.airmineral);
                break;
            case 2:
                txtOrderr="Jus Apel\nRp 123";
                txtOrder.setText(txtOrderr);
                imgOrder.setImageResource(R.drawable.jusapel);
                break;
            case 3:
                txtOrderr="Jus Mangga\nRp 123";
                txtOrder.setText(txtOrderr);
                imgOrder.setImageResource(R.drawable.jusmangga);
                break;
            case 4:
                txtOrderr="Jus Alpukat\nRp 123";
                txtOrder.setText(txtOrderr);
                imgOrder.setImageResource(R.drawable.jusalpukat);
                break;
        }
    }
    public void switchh(Integer x){
        String Quantity="0";
         Quantity=((EditText)findViewById(R.id.Qty)).getText().toString();
        Integer Qty=Integer.parseInt(Quantity);
        switch (x){
            case 1:
                MyOrderActivity.AM=MyOrderActivity.AM+Qty;
                Qty=0;
                break;
            case 2:
                MyOrderActivity.jApel=MyOrderActivity.jApel+Qty; Qty=0;
                break;
            case 3:
                MyOrderActivity.jMangga=MyOrderActivity.jMangga+Qty; Qty=0;
                break;
            case 4:
                MyOrderActivity.jAlpukat=MyOrderActivity.jAlpukat+Qty; Qty=0;
                break;
            case 0:
                break;
        }
    }
    @Override
    public void onClick(View view) {
        Intent moveIntent;
        switch (view.getId()){
            case (R.id.btnMyOrder) :
                switchh(order);

                moveIntent = new Intent(OrderAcitvity.this, MyOrderActivity.class);
                startActivity(moveIntent);
                break;
            case (R.id.btnOrderMore) :
                switchh(order);
                moveIntent = new Intent(OrderAcitvity.this, DrinksActivity.class);
                startActivity(moveIntent);
                break;
        }
    }
}
