package tianss.n.uts;

import androidx.fragment.app.FragmentActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.SearchView;
import java.util.*;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private AddressData data;
    private SearchView searchView;
    private SupportMapFragment mapFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        searchView = findViewById(R.id.sv_location);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                String location = searchView.getQuery().toString();
                List<Address> addressList = null;
                Geocoder geo = new Geocoder(MapsActivity.this);
                try {
                    addressList = geo.getFromLocationName(location,1);
                }catch (Exception e){
                    e.printStackTrace();
                }
                Address address = addressList.get(0);
                zoomTo(address,location);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                newText = searchView.getQuery().toString();
                List<Address> addresses = null;
                if(newText!=null || !newText.equals("")){
                    Geocoder geo = new Geocoder(MapsActivity.this);
                    try {
                        addresses = geo.getFromLocationName(newText,1);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });
        mapFragment.getMapAsync(this);
    }
    public void zoomTo(Address address, String location){

        LatLng latLng = new LatLng(address.getLatitude(),address.getLongitude());
        data.setAddress(address,location);
        mMap.addMarker((new MarkerOptions().position(latLng).title(location)));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        data = AddressData.getInstance();
        if(data.isSet()){
            Address address = data.getAddress();
            zoomTo(address,data.getLocation());
            searchView.setQuery(data.getLocation(),false);
            searchView.clearFocus();
        }
    }
}
