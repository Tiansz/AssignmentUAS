package tianss.n.uts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;



public class DrinksActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);
        Button btnMyOrder = findViewById(R.id.btnMyOrder);
        ImageView imgAir=findViewById(R.id.imgAir);
        ImageView imgApel=findViewById(R.id.imgApel);
        ImageView imgMangga=findViewById(R.id.imgMangga);
        ImageView imgAlpukat=findViewById(R.id.imgAlpukat);
        TextView txtAir=findViewById(R.id.txtAir);
        TextView txtApel=findViewById(R.id.txtApel);
        TextView txtMangga=findViewById(R.id.txtMangga);
        TextView txtAlpukat=findViewById(R.id.txtAlpukat);
        btnMyOrder.setOnClickListener(this);
        imgAir.setOnClickListener(this);
        imgApel.setOnClickListener(this);
        imgMangga.setOnClickListener(this);
        imgAlpukat.setOnClickListener(this);
        txtAir.setOnClickListener(this);
        txtApel.setOnClickListener(this);
        txtMangga.setOnClickListener(this);
        txtAlpukat.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent moveIntent;
        switch (view.getId()){
            case (R.id.btnMyOrder) :
                moveIntent = new Intent(DrinksActivity.this, MyOrderActivity.class);
                startActivity(moveIntent);
                break;
            case (R.id.imgAir) :
                OrderAcitvity.order=1;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.imgApel) :
                OrderAcitvity.order=2;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.imgMangga) :
                OrderAcitvity.order=3;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.imgAlpukat) :
                OrderAcitvity.order=4;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.txtAir) :
                OrderAcitvity.order=1;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.txtApel) :
                OrderAcitvity.order=2;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.txtMangga) :
                OrderAcitvity.order=3;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
            case (R.id.txtAlpukat) :
                OrderAcitvity.order=4;
                moveIntent = new Intent(DrinksActivity.this, OrderAcitvity.class);
                startActivity(moveIntent);
                break;
        }
    }
}
