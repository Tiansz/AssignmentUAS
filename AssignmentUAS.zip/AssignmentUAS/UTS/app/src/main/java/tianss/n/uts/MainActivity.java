package tianss.n.uts;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.*;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnMyOrder = findViewById(R.id.btnMyOrder);
        TextView txtDrinks=findViewById(R.id.txtDrinks);
        ImageView imgDrinks=findViewById(R.id.imgDrinks);
        btnMyOrder.setOnClickListener(this);
        txtDrinks.setOnClickListener(this);
        imgDrinks.setOnClickListener(this);
        TextView txtMaps=findViewById(R.id.txtMaps);
        txtMaps.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        Intent moveIntent;
        switch (view.getId()){
            case R.id.btnMyOrder:
                 moveIntent = new Intent(MainActivity.this, MyOrderActivity.class);
                startActivity(moveIntent);
                break;
            case R.id.txtDrinks:
                 moveIntent = new Intent(MainActivity.this, DrinksActivity.class);
                startActivity(moveIntent);
                break;
            case R.id.imgDrinks:
                moveIntent = new Intent(MainActivity.this, DrinksActivity.class);
                startActivity(moveIntent);
                break;
            case R.id.txtMaps:
                moveIntent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(moveIntent);
                break;
        }
    }
}
